# INMO AIR2 SDK
# Introduction

## Overview
The INMO AIR2 SDK is a platform provided by INMO for AR content developers. Developers use the INMO AIR2 SDK for development. After the development is completed, they apply for uploading to the INMO app store. After the approval, consumers with INMO AIR2 AR glasses can purchase and download them directly.
INMO AIR2 SDK provides a development kit based on INMO AIR2 AR glasses for UI design, interactive adaptation, INMO Ring2 and basic SLAM AR 6DOF capabilities, supporting Unity platform development and Android platform native development, allowing developers to quickly integrate and develop applications that can run on INMO AIR2 AR glasses.

## Development specifications
### Listing process
![](/images/commit.PNG) 
#### Enable adb
[How to get adb debug permissions](adb.md)
### About the application package name and signature
#### Package name rules
INMO Air2 applications use the Package Name as the unique identifier of the application.
- Naming rules for package names
It can only contain uppercase letters (A to Z), lowercase letters (a to z), numbers and underscores. Separated by dots (full stops), it is called a break. It must contain at least 2 breaks. Each separated paragraph must start with a letter.
- Avoid package name conflicts
If the package name of an application that has not yet been released duplicates the application that other developers have already released, it is recommended to modify the package name of the application immediately to avoid conflicts.
- Package name modification
After the application is released, please do not modify the package name. Once you modify the package name, it will be treated as a new application, and older users will not be able to receive the upgrade reminder from the app store.
#### About app signature
To ensure that updates to the application are submitted by the author himself, the submission of the application requires a signature.
- All applications must be signed. Unsigned applications are not allowed to go online.
- During the testing and development phase, you can use the debug key to sign the application and submit it for testing.
- When the application is ready for release, you need to create your own release key to sign the application. The required tools are included in the SDK tools.
- You can use the standard tools - keytool and jarsigner/apksigner - to generate CDKEY and sign apk.
- Before signing, we recommend that you use the zipalign tool to optimize the apk package.
### Developer Terms
See[Developer Terms](terms.md) 

# Version update instructions
|Version | Time | Update Notes |
|----------|:-------------:|------:|
|1.0.0 | 2023.3.30 | Minimum version to achieve 6dof spatial positioning capability |

# Android SDK
## SDK Function Introduction
This section provides a development guide for the INMO AIR2 SDK Android platform, including how to adapt and develop INMO RING2, trackpad interactive development, cameras and sensors using INMO Air2 AR glasses, etc.; and AR capability development kit for Android platform
### Get started 
#### Download the Android demo
git clone [https://gitee.com/inmolens/inmo-ar-sdk-sample.git]()
#### Environmental dependence
- Android Studio。
- JDK 11。

#### SDK AAR Package
Introduce dependent methods:
1. Add repository dependencies to the project build.gradle (for older versions of Android Studio in settings.gradle):
```java
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        jcenter()
        maven { url 'https://jitpack.io' }
        //add inmosdk repositories
        maven{url 'https://gitee.com/inmolens/inmo-ar-sdk/raw/master'}
    }
}
```
2. 2. Add the inmo sdk remote dependency in the build.gralde of the app module:
```java
dependencies {
    //INMO AR SDK
    implementation 'com.inmo:inmo_arsdk:0.0.1'
    ......
}
```

#### System requirements
If you need to run the AR service, please ensure that your INMO Glass Air system version is above version 2.4.


## INMO RING2 Development Adaptation
### Introduction
This section describes how to adapt the interaction using the INMO Ring2 ring for apps running on the INMO Air2 AR glasses 
### API Reference
In INMO Air2, when INMO Ring2 has been successfully connected to INMO Air2, the key event of INMO Ring2 is transmitted to the application layer with a key value code. Taking Activity as an example, the onKeyDown method is rewritten, and the code is processed according to different keycodes in the method body:
```java
public class MainActivity extends AppCompatActivity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
 
    //Respond to the INMO Ring2 keystroke
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            //Here, your code is handled according to the keycode of INMO Ring2
        }
        return super.onKeyDown(keyCode, event);
    }
}
```
INMO Ring2 currently provides more than 5 key functions, allowing developers to build rich application interactions. For the key value table of different buttons, please refer to the key value table in this section
### Ring key value table
|Keys | Functions | Keycode | Remarks |
|:----------|:-------------:|:-------------:|:-------------|
| Click "OK" Key | Confirm | 66 | KEYCODE_ENTER |
| Click "Up" | Direction Up | 19 | KEYCODE_DPAD_UP |
| Click "Down" Key | Direction Down | 20 | KEYCODE_DPAD_DOWN |
| Click "Left" Key | Direction Left | 21 | KEYCODE_DPAD_LEFT |
| Click "Right" Key | Direction Right | 22 | KEYCODE_DPAD_RIGHT |
| Click "Back" key | Exit/Return | 4 | KEYCODE_BACK |
| Double-click "Back" Key | Back to Desktop | 3 | KEYCODE_HOME |

## INMO Air2 Trackpad Interactive Adaptation
### Introduction
This section introduces how to use the touchpad at the temple on the INMO Air2 AR glasses to build and develop an Android App that runs on the INMO Air2 AR glasses. Refer to the demo program in the SDK to build a touch-based interaction that runs on the INMO Air2 AR glasses App; Demo will provide some information on how to build controls that run and interact with the INMO Air2 AR glasses. Developers can refer to and build their own App. (But developers may need to have some understanding of the Android event distribution system).
### API Reference
In INMO Air2, the touch gesture of the touchpad is transmitted to the application layer with a key value code. Taking Activity as an example, the onKeyDown method is rewritten, and the corresponding business logic is processed according to different keycodes in the method body:

```java
public class MainActivity extends AppCompatActivity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
 
    //Respond to the touchpad gesture
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            //Here, your code is handled according to the keycode of gesture
        }
        return super.onKeyDown(keyCode, event);
    }
}
```
The trackpad of the INMO Air2 AR glasses currently offers more than 10 different gesture functions, allowing developers to build rich app interactions. For a key-value table of different gestures, please refer to the key-value table in this section

### Touchpad key value table

|Gestures/Keys (Right Trackpad) | Keycode | Remarks |
|-------------|:---------:|--------------------|
|Single/double finger, Click | 66 | KEYCODE_ENTER |
|Single/double finger, double tap | 4 | KEYCODE_BACK |
|Single finger long press | 289 |/|
Single finger stroke forward | 22 | KEYCODE_DPAD_RIGHT |
Single finger stroke back| 21 | KEYCODE_DPAD_LEFT |
Single finger stroke up | 19 | KEYCODE_DPAD_UP |
Single finger stroke down | 20 | KEYCODE_DPAD_DOWN |
Double finger long press | 290 |/|
Double finger forward stroke | / | continuous reporting KEYCODE_DPAD_RIGHT |
Double finger stroke back| / | continuous reporting KEYCODE_DPAD_LEFT |
Double finger stroke up| / | continuous reporting KEYCODE_DPAD_UP |
Double finger stroke down | / | continuous reporting KEYCODE_DPAD_DOWN |

## Cameras, sensors and other peripherals
### Opening Camera 
INMO Air2 AR glasses are deeply customized based on the Android system, so accessing hardware such as cameras is perfectly compatible with the SDK developed by Android; the recommended ways to obtain camera objects and open them on INMO Air2 are as follows:
```java
private Camera camera;
private int INMO_AIR2_RGB_CAMERA_ID = 0;
camera = Camera.open(INMO_AIR2_RGB_CAMERA_ID);
```
## Development of other peripherals such as sensors
INMO Air2 AR glasses are deeply customized based on the Android system, so they are compatible with the universal interface of the Android platform. To access external devices and sensors, you can refer to the official Android reference doc: https://developer.android.google.cn/docs

## Native Android AR Development
### Introduction
This section introduces how to use INMO AR service to build applications that can run on INMO Air2 AR glasses. INMO AR service is a set of algorithms and services for building augmented reality applications on Inmo AR glasses. Currently, the algorithm supports 6dof spatial positioning capability. Due to computing power and battery capacity limitations, loop detection, plane detection, occlusion detection, illumination estimation, environment understanding and other capabilities required to achieve better virtual and real superposition effects are not supported for the time being. Optimization and release will be gradually implemented in the future.


## API Reference
### ArServiceSession class
This class is responsible for managing and implementing binder communication for ArService, and providing data and control interfaces.


Method Name | Description |
|----------|:-------------|
ArServiceSession (Context context) | Constructor of ArServiceSession class, pass in Application context, initialize related content |
getVersion () | Get ArService version number |
Create () | Create ArServiceSession, start the service |
Destroy () | Destroy ArServiceSession, clean all data |
getPose () | Gets the current device's position and attitude relative to the world coordinate system |
getProjectionMatrix ( int offset, float near, float far) | Get the projection matrix, which can be used to render virtual images in optomechanical images |
getViewMatrix () | Get a view matrix that can be used to render virtual images in optomechanical images |
Pause () | Pause, release camera without clearing data |
Resume () | resume operation |


### Detailed interface
#### ArServiceSession
```java
/** Creates a session bound to context to start and bind a service
* @return void
*/
public ArServiceSession(Context context)

/**
* Get the ArService version number
*
* @return
*/
public String getVersion()

/**
* Create a Session and start the service
*
* @return true: success false: failure
*/
public boolean create()

/**
* Destroy Session and clean up all data. But service doesn't have to stop. If there are other processes accessing the service, the service will continue to be provided. Otherwise, the service stops.
* @param
* @return void
*/
public void destroy()

/**
Obtain the position and attitude of the current device with respect to the world coordinate system, including a position vector and a rotation quaternion.
* Data storage sequence:
* [0]~[2]- Position vectors: x, y, z
* [3]~[6]- quaternions: w, x, y, z
* @return float[]
*/
public float[] getPose()

/**
* Gets a projection matrix that can be used to render virtual images in optical frames.
* @param width: width of the viewport, in pixels
* @param height: height of viewport, unit: pixel
* @param near: The distance from the cutting surface, in meters
* @param far: distance from the cutting surface, in meters
* @return float[] A matrix of 16 float numbers
*/
public float [] getProjectionMatrix(int width,int height,float near, float far)

/**
* Gets the optical machine view matrix, which can be used to render virtual images in the optical screen.
* @return float[] A matrix of 16 float numbers
*/
public float [] getViewMatrix()

/**
* Pause, release camera, but do not clear data.
* @return void
*/
public void pause()

/**
* Resume operation.
* @return void
*/
public void resume()
```


# Unity SDK
## SDK Function Introduction
This section provides a development guide for the INMO AIR2 SDK Unity platform, which introduces how to adapt and develop INMO RING2 on INMO Air2, interactive development of INMO Air2 AR glasses trackpad, and AR capability development kit for Unity platform.
## Get started
### Download the SDK
### Environment configuration
#### Software environment
- Unity Hub with Unity 2020.3LTS or higher and Android Support Module installed
- Visual Studio 2019
To install Unity Hub and the Unity Editor, visit the Unity website. https://unity.cn/
How to Install Android Support?
Open Unity Hub, click Install on the left, select the version that needs to install Android Support, and click the Pinion button.

![](/images/install_unity.png)
Click Add Module, find Android Build Support and click Install. After the installation is complete, the Android tab will be displayed under the version.
Visual Studio 2019 is recommended to install using the Add Module above.
The correspondence between Android NDK and Unity version is as follows, it is recommended to install it using Unity Hub
| Unity version | NDK version   |
|---------------|---------------|
| 2020.3 LTS    | r19           |
| 2021.3 LTS    | r21d          |

#### Hardware environment
- Inmo air2 glasses
- INMO RING2 Ring
#### Import SDK
inmo_unity_sdk package structure is as follows:
![](/images/import_unity.png)
Samples is an example provided by the SDK . Under the SDK is the aar library of the AR service, the URP is the pipeline configuration. If your project has a URP configuration or uses the Build-in pipeline, you can delete the URP folder, Document is an offline doc, and InmoUnitySdk is an sdk assembly.
Import Guide:
- New Project/Existing Project, File- > Build Settings switch to Android platform
![](/images/unity_build_android.png)
- Import the latest unitypackage provided by sdk :
1. Drag the unitypackage directly into the Project window
2. Assets-- > Import Packaging - > Custom Packaging
Click the import button in the lower right corner of the page and wait for the compile to complete.
#### Packaging settings
Because the AR service is developed based on android-28, you need to configure the Minimum API Level to 28 when packaging.
The default Scripting Backend is Mono mode, Il2Cpp mode is recommended for better performance and scalability.
The SDK uses the ARMv7 architecture, so Target Architectures can uncheck ARM64 to reduce the package size.
It is recommended to cancel the check before the "Optimize Frame Rate" option when packaging, as shown below:
![](/images/unity_build_setting1.png)
![](/images/unity_build_setting2.png)

#### 3D Model Resource Requirements
INMO AIR2 Recommended Rendering Settings for Unity Development
- After testing, the same screen rendering is about 10 to 200,000 surfaces, the model needs to be lightweight and reduce the number of surfaces as much as possible
- Use only one Directional Light as a dynamic light source, multiple lights use lightmaps
- Set Render Shadows of Camera to Off, Shadow Type of Directional Light to No Shadows
- Camera's Field Of View is set to 13.4, Near to 0.1, and Far to 15.
- Avoid using low-performance shaders, such as the overall model HighLight stroke, which will double the number of surfaces in the model render

## INMO RING2 Development Adaptation
### Introduction
This section describes how to adapt apps running on INMO Air2 AR glasses to INMO Ring2 interactions
### Button adaptation

Keys | Functions | Keycode | Remarks |
|----------------|-------|---------|--------------------|
Click/Double-Click/Long Press "OK" Key | Confirm | 13 | KeyCode. Return |
Click/Double-Click/Long Press "Up" | Direction Up | 273 | KeyCode. UpArrow |
Click/Double-Click/Long Press the "Down" key | Direction Down | 274 | KeyCode. DownArrow |
Click/Double-Click/Long Press "Left" | Direction Left | 276 | KeyCode. LeftArrow |
Click/Double-Click/Long Press "Right" | Direction Right | 275 | KeyCode. RightArrow |
Click "Back" key | Exit/Return | 27 | KeyCode. Escape |
### 3Dof ray mode
Stay tuned.
### Mode switching
The ring has three control modes:
Long press the ring back button to switch modes
#### Remote control mode (default mode)
- Only reports the key value when the button is pressed, and there is no event without pressing the button.
#### Mouse mode
- In this mode, the ring is configured as a standard HID mouse, and the movement of the mouse x and y axes is controlled by the sensor. The underlying system will handle mouse events, and the application generally does not require additional processing.
- In this mode, the button can work normally, the only difference is that the "OK" button no longer reports KeyCode.Return, but is handled as the left button of the mouse.
#### Ray mod
- In this mode, the ring will report the attitude data of the ring itself, which is reported in a quaternion way. In unity, you can control the pointing of the virtual ray, or control the rotation of other virtual objects.
- The button works normally in this mode.


## INMO Air2 Trackpad Interactive Adaptation
### Feature Introduction
This section introduces how to use the trackpad at the temple on the INMO Air2 AR glasses to build and develop a Unity application running on the INMO Air2 AR glasses. Referring to the demo program in the SDK , you can build a touch-based interactive application running on the INMO Air2 AR glasses. App; Demo will provide some information on how to build controls that run and interact with INMO Air2 AR glasses. Developers can refer to and build their own App.
### API参考
```csharp
private void Update()
{
    // Listen to enter key, map Click the right touchpad (confirm button)
    if (Input.GetKeyDown(KeyCode.Return))
    {
    _singleClickToggle.isOn = true;
    }

    // Monitor ESC key, map Double click right touch pad (back button)
    if (Input.GetKeyDown(KeyCode.Escape))
    {
    _doubleClickToggle.isOn = true;
    }

    // Listen to the arrow key and map the single finger on the right touchpad
    if (Input.GetKeyDown(KeyCode.UpArrow))
    {
    _upScrollToggle.isOn = true;
    }
    if (Input.GetKeyDown(KeyCode.DownArrow))
    {
    _downScrollToggle.isOn = true;
    }
    if (Input.GetKeyDown(KeyCode.LeftArrow))
    {
    _forwardScrollToggle.isOn = true;
    }
    if (Input.GetKeyDown(KeyCode.RightArrow))
    {
    _backScrollToggle.isOn = true;
    }
}
```
### Key value table

Gestures/Keys (Right Trackpad) | Features | Keycode | Remarks |
|---------------|-------|---------|--------------------|
Single/Double finger, Click | Confirm | 13 | KeyCode. Return |
Single finger stroke up | Direction up | 273 | KeyCode. UpArrow |
Single finger stroke down| Direction down | 274 | KeyCode. DownArrow |
Single finger stroke back| Direction left | 276 | KeyCode. LeftArrow |
Single finger stroke forward | Direction Right | 275 | KeyCode. RightArrow |
Single/double finger, double click | exit/return | 27 | KeyCode. Escape |


## Unity AR Development
### Introduction
This section introduces how to use INMO AR service to build applications that can run on INMO Air2 AR glasses. INMO AR service is a set of algorithms and services for building augmented reality applications on Inmo AR glasses.
### API Reference
The ARService class is an interface to AR functionality.


Method Name | Description |
|---------------------|------------------|
ARService (Camera camera, float fov) | Constructor of the ARService class, pass in the camera and fov values to use, the fov value is recommended to be set to 13.4 |
getVersion () | Get AR service version number |
Create () | Create and start AR service |
Destroy () | Destroy the AR service and clean all data. But the service does not necessarily stop. If there are other processes accessing the service, the service will continue to be provided. Otherwise the service will be stopped. |
getPose () | Gets the current device's position and attitude relative to the world coordinate system |
Pause () | Pause to release the camera without clearing the data.
Resume () | resume running. |



```csharp
namespace inmo.unity.sdk
{
    public class ARCamera : MonoBehaviour
    {
        //ar service
        private ARService _arService;

        // pose of glasses in space
        private ARPose _arpose;

        // fov of air2 glasses, 13.4f is recommended
        [SerializeField] private float _fieldOfView = 13.4f;

        //ar status text
        [SerializeField] private Text _arstatus;

        private void OnEnable()
        {
            // The InitARService button is selected by default
            GameObject.Find("UI Canvas/Buttons/InitAR").GetComponent().Select();
            _arstatus.text = "ar: not initialized ";
        }

        private void Update()
        {
            // Get the arpose for ar
            if(_arService ! = null && _arService.isOpen)
            {
            _arpose = _arService.GetARPose();
            }

            // Double-click the right touchpad to exit the app
            if(Input.GetKeyDown(KeyCode.Escape))
            {
            Application.Quit(0);
            }               
        }

        private void LateUpdate()
        {
        // Modify the camera through the arpose provided by ar
            if (_arpose ! = null)
            {
            Camera.main.transform.position = _arpose.position;
            Camera.main.transform.rotation = _arpose.rotation;
            }
        }

        # region AR communication event
        public void InitARService()
        {
        _arService = new ARService(Camera.main, _fieldOfView);
        _arstatus.text = "ar: initialized ";
        }

        public void CreateARService()
        {
            if (_arService ! = null)
            {
            _arService.Create();
            _arstatus.text = "ar: enabled ";
            }
        }

        public void PauseARService()
        {
            if (_arService ! = null)
            {
            _arService.Pause();
            _arstatus.text = "ar: suspended ";
            }
        }

        public void ResumeARService()
        {
            if (_arService ! = null)
            {
            _arService.Resume();
            _arstatus.text = "ar: enabled ";
            }
        }

        public void DestroyARService()
        {
            if (_arService ! = null)
            {
            _arService.Destroy();
            _arstatus.text = "ar: destroyed ";
            }
        }

        public void GetARServiceVersion()
        {
            if (_arService ! = null)
            {
            string version = _arService.GetVersion();
            _arstatus.text = "ar: "+ version;
            }
        }
        # endregion
    }
}
```