# inmo-ar-sdk-sample

#### 介绍
INMO AR sdk示例代码

#### 使用说明

1.  项目build.gradle中添加仓库依赖（高版本的Android Studio在settings.gradle）：

```
    dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        jcenter()
        maven { url 'https://jitpack.io' }
        //增加inmosdk仓库依赖
        maven{url 'https://gitee.com/inmolens/inmo-ar-sdk/raw/master'}
    }
    }
```

    
2.  app模块的build.gralde中添加inmo sdk远程依赖:

```
    dependencies {
        //INMO AR SDK
        implementation 'com.inmo:inmo_arsdk:0.0.1'

        ......
    }
```
更多接口参考，请参考sdk文档说明
        