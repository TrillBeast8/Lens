package com.inmo.inmoair2;

public class MainBean {
    private String name;

    public MainBean(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
